
package hmgmt.dao;

import hmgmt.dbutil.DBConnection;
import hmgmt.pojo.DoctorPojo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;



public class DoctorDao {
    public static ArrayList<String> getAllDoctorsId()throws SQLException
    {
        ArrayList<String>docId=new ArrayList<>();
        ResultSet rs=DBConnection.getConnection().createStatement().executeQuery("select doctorid from doctors where active='y'");
        while(rs.next())
        {
            docId.add(rs.getString(1));
        }
        return docId;
    }
    public static boolean addDoctors(DoctorPojo user)throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        String qry="insert into doctors values(?,?,?,?,?)";
        PreparedStatement ps=conn.prepareStatement(qry);
        ps.setString(1,user.getUserid());
        ps.setString(2,user.getDoctorid());
        ps.setString(3,user.getQualification());
        ps.setString(4,user.getSpecialist());
        ps.setString(5,user.getActive());
        int x=ps.executeUpdate();
        if(x>0)
            return true;
        return false;
    }
    public static HashMap<String,String> getNonRegisteredDoctorList()throws SQLException
    {
        Connection con=DBConnection.getConnection();
        String qry="select empid,ename from employees where role='DOCTOR' and empid not in(select empid from users where usertype='DOCTOR')";
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(qry);
        HashMap<String,String> doctor=new HashMap();
        while(rs.next()){
            
            String id=rs.getString(1);
            String name=rs.getString(2);
            //System.out.println(name+" "+id);
            doctor.put(id,name);
            
        }
        return doctor;
    }
    public static ArrayList<DoctorPojo>getAllData()throws SQLException
    {
        Statement st = DBConnection.getConnection().createStatement();
        ResultSet rs = st.executeQuery("select * from doctors");
        ArrayList <DoctorPojo> doctorList = new ArrayList<>();
        while(rs.next())
        {
            DoctorPojo d = new DoctorPojo();
            d.setUserid(rs.getString(1));
            d.setDoctorid(rs.getString(2));
            d.setQualification(rs.getString(3));
            d.setSpecialist(rs.getString(4));
            doctorList.add(d);
        }
        return doctorList;
    }
    public static boolean removeDoctor(String docId)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("update doctors set active='n' where doctorid=?");
        ps.setString(1, docId);
        int x = ps.executeUpdate();
        return(x>0);
    }
}


package hmgmt.dao;

import hmgmt.dbutil.DBConnection;
import hmgmt.pojo.EmpPojo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class EmpDao {
    
    public static String getNewID()throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Select count(*) from employees");
        int id = 101;
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            id += rs.getInt(1);
        }
        return "E"+(id);
    }
    public static boolean addEmp(EmpPojo e)throws SQLException
    {
        PreparedStatement ps=DBConnection.getConnection().prepareStatement("insert into employees values(?,?,?,?,?)");
        ps.setString(1,e.getEmpId());
        ps.setString(2,e.getEmpName());
        ps.setString(3,e.getJob());
        ps.setDouble(4,e.getSal());
        ps.setString(5,e.getActive());
        int x = ps.executeUpdate();
        return (x>0);
    }
    
    public static EmpPojo getEmployeesByEmpId(String id)throws SQLException
    {
       PreparedStatement ps = DBConnection.getConnection().prepareStatement("Select * from employees where empid=? and active='y'");
        //System.out.println(id);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        if(rs.next())
        {
            EmpPojo e = new EmpPojo();
            e.setEmpId(rs.getString(1));
            e.setEmpName(rs.getString(2));
            e.setJob(rs.getString(3));
            e.setSal(rs.getDouble(4));
            return e;
        }
        return null;
    }
    public static ArrayList<String> allEmpId()throws SQLException
    {
        PreparedStatement ps=DBConnection.getConnection().prepareStatement("select empid from employees where active='y'");
        ResultSet rs=ps.executeQuery();
        ArrayList<String>arr=new ArrayList();
        while(rs.next())
            arr.add(rs.getString(1));
        return arr;
    }
    
     public static ArrayList<EmpPojo>getAllData()throws SQLException
    {
        Statement st = DBConnection.getConnection().createStatement();
        ResultSet rs = st.executeQuery("select * from employees");
        ArrayList <EmpPojo> employeeList = new ArrayList<>();
        while(rs.next())
        {
            EmpPojo e = new EmpPojo();
            e.setEmpId(rs.getString(1));
            e.setEmpName(rs.getString(2));
            e.setJob(rs.getString(3));
            e.setSal(rs.getDouble(4));
            employeeList.add(e);
        }
        return employeeList;
    }
    public static boolean updateEmployee(EmpPojo e)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Update employees set sal=? where empid=? and active='y'");
        //ps.setString(1, e.getEmpName());
        //ps.setString(2, e.getJob());
        ps.setDouble(1, e.getSal());
        ps.setString(2, e.getEmpId());
        int x = ps.executeUpdate();
        if(x==1)
            return true;
        return false;
    }
    public static boolean removeEmployee(String empId)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("update employees set active='n' where empid=?");
        ps.setString(1, empId);
        int x = ps.executeUpdate();
        return(x>0);
    }
    
    public static HashMap<String,String>getEmpId()throws SQLException
    {
        HashMap<String,String> employeeList=new HashMap<>();
        ResultSet rs=DBConnection.getConnection().createStatement().executeQuery("select empid,ename from employees where active='y'");
        while(rs.next())
            employeeList.put(rs.getString(1),rs.getString(2));
        return employeeList;
    }
     
}

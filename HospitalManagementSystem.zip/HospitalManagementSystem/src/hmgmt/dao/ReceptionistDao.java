
package hmgmt.dao;

import hmgmt.dbutil.DBConnection;
import hmgmt.pojo.EmpPojo;
import hmgmt.pojo.UserDetailsPojo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;


public class ReceptionistDao {
    public static boolean addReceptionist(UserDetailsPojo user)throws SQLException
    {
        PreparedStatement ps=DBConnection.getConnection().prepareStatement("insert into users values(?,?,?,?,?)");
        ps.setString(1,user.getUserId());
        ps.setString(4,user.getPassword());
        ps.setString(5,user.getUserType());
        ps.setString(2,user.getUserName());
        ps.setString(3,user.getEmpId());
        
        
        int x = ps.executeUpdate();
        return (x>0);
    }
    public static ArrayList<String> allReceptionistId()throws SQLException
    {
        PreparedStatement ps=DBConnection.getConnection().prepareStatement("select empid from users where usertype='RECEPTIONIST'");
        ResultSet rs=ps.executeQuery();
        ArrayList<String>arr=new ArrayList();
        while(rs.next())
            arr.add(rs.getString(1));
        return arr;
    }
    public static boolean removeReceptionist(String empId)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("delete from users where empid=?");
        ps.setString(1, empId);
        int x = ps.executeUpdate();
        return(x>0);
    }
    public static ArrayList<EmpPojo>getAllData()throws SQLException
    {
        Statement st = DBConnection.getConnection().createStatement();
        ResultSet rs = st.executeQuery("select * from employees where role='RECEPTIONIST'");
        ArrayList <EmpPojo> employeeList = new ArrayList<>();
        while(rs.next())
        {
            EmpPojo e = new EmpPojo();
            e.setEmpId(rs.getString(1));
            e.setEmpName(rs.getString(2));
            e.setJob(rs.getString(3));
            e.setSal(rs.getDouble(4));
            employeeList.add(e);
        }
        return employeeList;
    }
    public static HashMap<String,String> getNonRegisteredReceptionistList()throws SQLException
    {
        Connection con=DBConnection.getConnection();
        String qry="select empid,ename from employees where role='RECEPTIONIST' and empid not in(select empid from users where usertype='RECEPTIONIST')";
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(qry);
        HashMap<String,String> receptionist=new HashMap();
        while(rs.next()){
            
            String id=rs.getString(1);
            String name=rs.getString(2);
            //System.out.println(name+" "+id);
            receptionist.put(id,name);
            
        }
        return receptionist;
    }
}

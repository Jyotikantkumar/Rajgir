
package hmgmt.dao;

import hmgmt.dbutil.DBConnection;
import hmgmt.pojo.UserDetailsPojo;
import hmgmt.pojo.UserPojo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

public class UserDao {
    String username=null;
    public static String validateUser(UserPojo user)throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        String qry="select username from users where userid=? and password=? and usertype=?";
        PreparedStatement ps=conn.prepareStatement(qry);
        ps.setString(1,user.getUserId());
        ps.setString(2,user.getPassword());
        ps.setString(3,user.getUserType());
        ResultSet rs=ps.executeQuery();
        String username=null;
        if(rs.next())
            username=rs.getString(1);
        return username;
    }
    public static boolean changePassword(String userid,String pwd)throws SQLException
    {
        PreparedStatement ps=DBConnection.getConnection().prepareStatement("update users set password=? where userid=?");
        ps.setString(1,pwd);
        ps.setString(2, userid);
        return (ps.executeUpdate()!=0);
    }
    public static HashMap<String,String>getReceptionistList()throws SQLException
    {
        HashMap<String,String> receptionistList=new HashMap<>();
        ResultSet rs=DBConnection.getConnection().createStatement().executeQuery("select userid,username from users where usertype='RECEPTIONIST' or usertype='DOCTOR' or usertype='ADMIN'");
        while(rs.next())
            receptionistList.put(rs.getString(1),rs.getString(2));
        return receptionistList;
    }
    public static boolean addUser(UserDetailsPojo user)throws SQLException
    {
        PreparedStatement ps=DBConnection.getConnection().prepareStatement("insert into users values(?,?,?,?,?)");
        ps.setString(1,user.getUserId());
        ps.setString(4,user.getPassword());
        ps.setString(5,user.getUserType());
        ps.setString(2,user.getUserName());
        ps.setString(3,user.getEmpId());
        int x = ps.executeUpdate();
        return (x>0);
    }
    
    public static UserPojo getUserByUsersId(String id)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Select * from users where userid=?");
        //System.out.println(id);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            UserPojo p = new UserPojo();
            p.setUserId(rs.getString(1));
            p.setPassword(rs.getString(4));
            //System.out.println(p.toString());
            return p;
        }
        return null;
    }
}

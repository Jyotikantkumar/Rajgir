
package hmgmt.dao;

import hmgmt.dbutil.DBConnection;
import hmgmt.pojo.PatientPojo;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class PatientDao {
    
    public static String getNewId()throws SQLException
    {
        
        Connection conn=DBConnection.getConnection();
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("select max(p_id) from patient");
        int id=1;
        if(rs.next())
            {
                String empid=rs.getString(1);
                int eno=Integer.parseInt(empid.substring(1,4));
                id=id+eno;
                return "P"+id;
            }
        else
            return "P101";
    }
    public static boolean addPatient(PatientPojo p)throws SQLException
    {
        PreparedStatement ps=DBConnection.getConnection().prepareStatement("insert into patient values(?,?,?,?,?,?,?,?,?,?,?,?)");
        ps.setString(1,p.getP_id());
        ps.setString(2,p.getF_name());
        ps.setString(3,p.getS_name());
        ps.setInt(4,p.getAge());
        ps.setString(5,p.getOpd());
        ps.setString(6,p.getGender());
        ps.setString(7,p.getM_status());
        ps.setDate(8,p.getDate());
        ps.setString(9,p.getAddress());
        ps.setString(10,p.getCity());
        ps.setString(11,p.getMno());
        ps.setString(12,p.getDoctor_id());
        return (ps.executeUpdate()!=0);
    }
    public static boolean updatePatient(PatientPojo e)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("update patient set f_name=? ,s_name=? ,age=? ,opd=? ,gender=? ,m_status=?,address=?,city=?,phone_no=?  where p_id=?");
        ps.setString(1, e.getF_name());
        ps.setString(2, e.getS_name());
        ps.setInt(3, e.getAge());
        ps.setString(4, e.getOpd());
        ps.setString(5, e.getGender());
        ps.setString(6, e.getM_status());
        //ps.setDate(8, e.getDate());
        ps.setString(7, e.getAddress());
        ps.setString(8, e.getCity());
        ps.setString(9, e.getMno());
        ps.setString(10, e.getP_id());
        int x = ps.executeUpdate();
        if(x==1)
            return true;
        return false;
    }
    public static PatientPojo getPatientByPatientId(String id)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Select * from patient where p_id=?");
        //System.out.println(id);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            PatientPojo p = new PatientPojo();
            p.setP_id(rs.getString(1));
            p.setF_name(rs.getString(2));
            p.setS_name(rs.getString(3));
            p.setAge(rs.getInt(4));
            p.setOpd(rs.getString(5));
            p.setGender(rs.getString(6));
            p.setM_status(rs.getString(7));
            p.setDate(rs.getDate(8));
            p.setAddress(rs.getString(9));
            p.setCity(rs.getString(10));
            p.setMno(rs.getString(11));
            p.setDoctor_id(rs.getString(12));
            //System.out.println(p.toString());
            return p;
        }
        return null;
    }
    
    public static boolean removePatient(String patientId)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("delete from patient where p_id=?");
        ps.setString(1, patientId);
        int x = ps.executeUpdate();
        return(x>0);
    }
    public static ArrayList<String> getAllPatientsId()throws SQLException
    {
        ArrayList<String>patientId=new ArrayList<>();
        ResultSet rs=DBConnection.getConnection().createStatement().executeQuery("select p_id from patient");
        while(rs.next())
        {
            patientId.add(rs.getString(1));
        }
        return patientId;
    }
    public static ArrayList<PatientPojo>getAllData()throws SQLException
    {
        Statement st = DBConnection.getConnection().createStatement();
        ResultSet rs = st.executeQuery("select * from patient");
        ArrayList <PatientPojo> patientList = new ArrayList<>();
        while(rs.next())
        {
            PatientPojo p = new PatientPojo();
            p.setP_id(rs.getString(1));
            p.setF_name(rs.getString(2));
            p.setS_name(rs.getString(3));
            p.setAge(rs.getInt(4));
            p.setOpd(rs.getString(5));
            p.setGender(rs.getString(6));
            p.setM_status(rs.getString(7));
            p.setDate(rs.getDate(8));
            p.setAddress(rs.getString(9));
            p.setCity(rs.getString(10));
            p.setMno(rs.getString(11));
            p.setDoctor_id(rs.getString(12));
            patientList.add(p);
        }
        return patientList;
    }
}
